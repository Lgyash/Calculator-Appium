Start Appium Server:

1- Open a terminal and run: Appium
== The server should start on http://127.0.0.1:4723

2- Launch the Android Emulator :
== Ensure the emulator is running : adb devices

3- Run Tests with Maven :

== Navigate to the project root and run: mvn test

=== The console will display test execution results.



=== Prerequisites ===

== Ensure the following are installed on your machine:

1- Java Development Kit (JDK)

2- Android Studio

3- Node.js and npm

4- Appium Server

5- Appium Desktop (GUI version)

6- Android Emulator : Create one in Android Studio > AVD Manager


** MADE WITH THE HELP OF AI. **
=========================================================================